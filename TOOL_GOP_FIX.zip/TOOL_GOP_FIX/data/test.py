import requests

headers = {
    'Accept': '*/*',
    'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json; charset=UTF-8',
    'Origin': 'https://www.tiktok.com',
    'Pragma': 'no-cache',
    'Referer': 'https://www.tiktok.com/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    'sec-ch-ua': '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

json_data = [
    {
        'events': [
            {
                'event': 'like',
                'params': '{"page_name":"homepage_hot","enter_from":"homepage_hot","time_from_origin":2766490,"is_landing_page":0,"previous_page":"personal_homepage","page_url":"https://www.tiktok.com/vi-VN","userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36","user_type_alias":"user","domain_name":"www.tiktok.com","page_path":"/vi-VN","vidab":"70508271,71767682,72213608,72245120,72313476,72394607,72406135,72422413,72437276,72507662,72508750,72515706,72515779,72519879,72537565,72556480,72602618,72607427,72612481,72619473,72620774,72637609,72637698,72651443,72653052,72670820,72679386,72680698,70138197,70156809,70405643,71057832,71200802,71381811,71516509,71803300,71962127,72258247,72360691,72408100,72445639,72562770","seo_vidab":"","is_non_personalized":"0","data_collection_enabled":1,"play_mode":"one_column","group_id":"7401717826966277406","author_id":"7252923019850253358","log_pb":{"impr_id":"2024082308500211462790BFF85D0405AB"},"enter_method":"click","aweme_type":0,"is_sub_only_video":0,"from_group_id":"7398866808964418824","prediction_payload":"0,1,0,0,0,0,0,48,12,6,19,0,0,0,0,19,39,1.9500000000000004,4.13,1,19,11,4,0.9100000000000001,2,2.26,1,0,0,0,0,133.82000000000062,0,6,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,20,1,1,1,1,15,-7,0,0,0,1","event_index":1724400389935}',
                'local_time_ms': 1724403003793,
                'is_bav': 1,
                'ab_sdk_version': '72678466',
                'session_id': 'd276ccb6-028a-43ef-b2d5-f2646e82eabd',
            },
        ],
        'user': {
            'user_unique_id': '7367343549308732936',
            'user_type': 12,
            'user_id': '6816734450833130497',
            'user_is_login': True,
            'device_id': '7367343549308732936',
        },
        'header': {
            'app_id': 1988,
            'os_name': 'windows',
            'os_version': '10',
            'device_model': 'Windows NT 10.0',
            'language': 'vi',
            'region': 'VN',
            'platform': 'web',
            'sdk_version': '5.2.7_oversea',
            'sdk_lib': 'js',
            'timezone': 7,
            'tz_offset': -25200,
            'resolution': '1536x864',
            'browser': 'Chrome',
            'browser_version': '127.0.0.0',
            'referrer': 'https://www.tiktok.com/vi-VN',
            'referrer_host': 'www.tiktok.com',
            'width': 1536,
            'height': 864,
            'screen_width': 1536,
            'screen_height': 864,
            'tracer_data': '{"$utm_from_url":1}',
            'custom': '{"session_id":"73673435493087329361724400215706","device":"pc","launch_mode":"direct","traffic_type":"no_referrer","source":"","referer_url":"https://www.tiktok.com/","browserName":"google","hevcSupported":1,"cpu_core":12,"release":"1.0.2.267","user_is_login":1,"priority_region":"VN","landing_page":"homepage_hot","is_kids_mode":0,"region":"VN","extraData":"{}","is_downgrade":false,"app_language":"vi-VN","is_sharing":0,"vidab":"70508271,71767682,72213608,72245120,72313476,72394607,72406135,72422413,72437276,72507662,72508750,72515706,72515779,72519879,72537565,72556480,72602618,72607427,72612481,72619473,72620774,72637609,72637698,72651443,72653052,72670820,72679386,72680698,70138197,70156809,70405643,71057832,71200802,71381811,71516509,71803300,71962127,72258247,72360691,72408100,72445639,72562770","seo_vidab":"","b_c":"0","max_touch_points":0,"network_downlink":10,"network_rtt":250,"network_speed_effective_type":"4g"}',
        },
        'local_time': 1724403003,
        'verbose': 1,
    },
]

response = requests.post('https://mcs-sg.tiktokv.com/v1/list', headers=headers, json=json_data)

# Note: json_data will not be serialized by requests
# exactly as it was in the original request.
#data = '[{"events":[{"event":"like","params":"{\\"page_name\\":\\"homepage_hot\\",\\"enter_from\\":\\"homepage_hot\\",\\"time_from_origin\\":2766490,\\"is_landing_page\\":0,\\"previous_page\\":\\"personal_homepage\\",\\"page_url\\":\\"https://www.tiktok.com/vi-VN\\",\\"userAgent\\":\\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36\\",\\"user_type_alias\\":\\"user\\",\\"domain_name\\":\\"www.tiktok.com\\",\\"page_path\\":\\"/vi-VN\\",\\"vidab\\":\\"70508271,71767682,72213608,72245120,72313476,72394607,72406135,72422413,72437276,72507662,72508750,72515706,72515779,72519879,72537565,72556480,72602618,72607427,72612481,72619473,72620774,72637609,72637698,72651443,72653052,72670820,72679386,72680698,70138197,70156809,70405643,71057832,71200802,71381811,71516509,71803300,71962127,72258247,72360691,72408100,72445639,72562770\\",\\"seo_vidab\\":\\"\\",\\"is_non_personalized\\":\\"0\\",\\"data_collection_enabled\\":1,\\"play_mode\\":\\"one_column\\",\\"group_id\\":\\"7401717826966277406\\",\\"author_id\\":\\"7252923019850253358\\",\\"log_pb\\":{\\"impr_id\\":\\"2024082308500211462790BFF85D0405AB\\"},\\"enter_method\\":\\"click\\",\\"aweme_type\\":0,\\"is_sub_only_video\\":0,\\"from_group_id\\":\\"7398866808964418824\\",\\"prediction_payload\\":\\"0,1,0,0,0,0,0,48,12,6,19,0,0,0,0,19,39,1.9500000000000004,4.13,1,19,11,4,0.9100000000000001,2,2.26,1,0,0,0,0,133.82000000000062,0,6,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,20,1,1,1,1,15,-7,0,0,0,1\\",\\"event_index\\":1724400389935}","local_time_ms":1724403003793,"is_bav":1,"ab_sdk_version":"72678466","session_id":"d276ccb6-028a-43ef-b2d5-f2646e82eabd"}],"user":{"user_unique_id":"7367343549308732936","user_type":12,"user_id":"6816734450833130497","user_is_login":true,"device_id":"7367343549308732936"},"header":{"app_id":1988,"os_name":"windows","os_version":"10","device_model":"Windows NT 10.0","language":"vi","region":"VN","platform":"web","sdk_version":"5.2.7_oversea","sdk_lib":"js","timezone":7,"tz_offset":-25200,"resolution":"1536x864","browser":"Chrome","browser_version":"127.0.0.0","referrer":"https://www.tiktok.com/vi-VN","referrer_host":"www.tiktok.com","width":1536,"height":864,"screen_width":1536,"screen_height":864,"tracer_data":"{\\"$utm_from_url\\":1}","custom":"{\\"session_id\\":\\"73673435493087329361724400215706\\",\\"device\\":\\"pc\\",\\"launch_mode\\":\\"direct\\",\\"traffic_type\\":\\"no_referrer\\",\\"source\\":\\"\\",\\"referer_url\\":\\"https://www.tiktok.com/\\",\\"browserName\\":\\"google\\",\\"hevcSupported\\":1,\\"cpu_core\\":12,\\"release\\":\\"1.0.2.267\\",\\"user_is_login\\":1,\\"priority_region\\":\\"VN\\",\\"landing_page\\":\\"homepage_hot\\",\\"is_kids_mode\\":0,\\"region\\":\\"VN\\",\\"extraData\\":\\"{}\\",\\"is_downgrade\\":false,\\"app_language\\":\\"vi-VN\\",\\"is_sharing\\":0,\\"vidab\\":\\"70508271,71767682,72213608,72245120,72313476,72394607,72406135,72422413,72437276,72507662,72508750,72515706,72515779,72519879,72537565,72556480,72602618,72607427,72612481,72619473,72620774,72637609,72637698,72651443,72653052,72670820,72679386,72680698,70138197,70156809,70405643,71057832,71200802,71381811,71516509,71803300,71962127,72258247,72360691,72408100,72445639,72562770\\",\\"seo_vidab\\":\\"\\",\\"b_c\\":\\"0\\",\\"max_touch_points\\":0,\\"network_downlink\\":10,\\"network_rtt\\":250,\\"network_speed_effective_type\\":\\"4g\\"}"},"local_time":1724403003,"verbose":1}]'
#response = requests.post('https://mcs-sg.tiktokv.com/v1/list', headers=headers, data=data)